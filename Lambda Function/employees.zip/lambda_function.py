import json
import boto3
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('employees-info')

def lambda_handler(event, context):
    
    method = event['httpMethod']
    path = event['path']
    
    if method == "GET" and path == "/get_employees":
        response = get_employees()
    elif method == "DELETE" and path == "/delete_employee":
        id = event['queryStringParameters']['id']
        response = delete_employee(id)
    elif method == "PATCH" and path == "/edit_employee":
        request_body = json.loads(event['body'])
        response = edit_employee(request_body)
    elif method == "POST" and path == "/add_employee":
        request_body = json.loads(event['body'])
        response = add_employee(request_body)

    return response
    
def add_employee(request_body):
    try:
        table.put_item(Item=request_body)
        body = {'message': 'Employee added successfully'}
        return buildResponse(200, body)
    except Exception as e:
        return buildResponse(500, 'Internal Server Error')

def get_employees():
    try:
        response = table.scan()
        body = {
            'employeesList': response['Items']
        }
        return buildResponse(200, body)
    except Exception as e:
        print(f'An error occurred in fetching the employees: {str(e)}')
        return buildResponse(500, 'Internal Server Error')

def delete_employee(id):
    try:
        print("id: ", id)
        table.delete_item(
            Key={'id': int(id)}
        )
        body = {'message': 'Employee deleted successfully'}
        return buildResponse(200, body)
    except Exception as e:
        print(f'An error occurred in deleting the employee: {str(e)}')
        return buildResponse(500, "error in deleting")
        
def edit_employee(request_body):
    try:
        id = request_body['id']
        response = table.update_item(
            Key={'id': id},
            UpdateExpression='SET firstName = :val1, lastName = :val2, email = :val3, salary = :val4, #dt = :val5, uid = :val6',
            ExpressionAttributeValues={
                ':val1': request_body['firstName'],
                ':val2': request_body['lastName'],
                ':val3': request_body['email'],
                ':val4': request_body['salary'],
                ':val5': request_body['date'],
                ':val6': request_body['uid']
            },
            ExpressionAttributeNames={
                '#dt': 'date'  
            },
            ReturnValues='ALL_NEW'
        )
        return buildResponse(200, response['Attributes'])
            
    except Exception as e:
        return buildResponse(500, {'error': str(e)})


def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH,DELE"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body, cls=DecimalEncoder)
    return response