import json
import boto3
import base64
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

s3 = boto3.client('s3')
bucket_name = 'cloud-arch-employees'

def lambda_handler(event, context):
    request_body = json.loads(event['body'])
    path = event['path']
    
    if path == "/uploadImage":
        image_data = request_body["data"]
        key = request_body['filename']
        decode_image_data = base64.b64decode(image_data)
        response = uploadImage(key, decode_image_data)
    elif path == "/getImage":
        key = request_body['filename']
        response = getImage(key)
    elif path == "/deleteImage":
        key = request_body['filename']
        response = deleteImage(key)
    else:
        response = buildResponse(400, {'error': 'Invalid path'})

    return response

def uploadImage(key, decode_image_data):
    try:
        s3.put_object(Bucket=bucket_name, Key=key, Body=decode_image_data, ContentType='image/jpeg')
        return buildResponse(200, {'message': 'Image uploaded successfully', 'key': key})
    except Exception as e:
        return buildResponse(500, {'error': str(e)})

def getImage(key):
    try:
        response = s3.get_object(Bucket=bucket_name, Key=key)
        image_data = response['Body'].read()
        encoded_image = base64.b64encode(image_data).decode('utf-8')
        return buildResponse(200, {'image_data': encoded_image, 'key': key})
    except Exception as e:
        return buildResponse(500, {'error': str(e)})

def deleteImage(key):
    try:
        s3.delete_object(Bucket=bucket_name, Key=key)
        return buildResponse(200, {'message': 'Image deleted successfully', 'key': key})
    except Exception as e:
        return buildResponse(500, {'error': str(e)})

def buildResponse(statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PATCH,DELETE"
        }
    }
    if body is not None:
        response['body'] = json.dumps(body, cls=DecimalEncoder)
    return response
